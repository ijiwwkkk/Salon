﻿using System;

namespace Salon.Models
{
    public class User
    {
        public int Id { get; set; }
        public string FullName { get; set; } = "";
        public string Email { get; set; } = "";
        public string Password { get; set; } = "";
        public string Role { get; set; } = "Client";
        public List<Service> Services { get; set; } = new();
    }

    public class Service
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Category { get; set; } = "Стрижки";
        public decimal Price { get; set; }
        public int DurationMinutes { get; set; } = 60;
        public string Description { get; set; } = "";

        public string? ImageUrl { get; set; }

        public int? MasterId { get; set; }
        public User? Master { get; set; }
    }

    public class PromoCard
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string? ImageUrl { get; set; }
    }

    public class GalleryItem
    {
        public int Id { get; set; }
        public string LayoutGroup { get; set; } = "left";
        public string? ImageUrl { get; set; }
    }

    public class Appointment
    {
        public int Id { get; set; }
        public DateTime DateTime { get; set; }
        public string Status { get; set; } = "Создана";
        public string ClientComment { get; set; } = "";
        public string MasterComment { get; set; } = "";

        public int ClientId { get; set; }
        public User? Client { get; set; }

        public int MasterId { get; set; }
        public User? Master { get; set; }

        public int ServiceId { get; set; }
        public Service? Service { get; set; }
    }

    public class InventoryItem
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Category { get; set; } = "Материал"; 
        public int QuantityInStock { get; set; }
        public string Unit { get; set; } = "шт."; 
        public decimal Price { get; set; } 
    }
    public class ServiceMaterial
    {
        public int Id { get; set; }
        public int ServiceId { get; set; }
        public Service? Service { get; set; } 
        public int InventoryItemId { get; set; }
        public InventoryItem? InventoryItem { get; set; }
        public decimal QuantityRequired { get; set; }
    }
    public class PurchaseRecord
    {
        public int Id { get; set; }
        public int InventoryItemId { get; set; }
        public InventoryItem? InventoryItem { get; set; }
        public DateTime PurchaseDate { get; set; } = DateTime.Now;
        public int QuantityAdded { get; set; }
        public decimal TotalCost { get; set; }
    }
    public class HeroImage
    {
        public int Id { get; set; }
        public string Key { get; set; } = "";
        public string? ImageUrl { get; set; }
    }

}