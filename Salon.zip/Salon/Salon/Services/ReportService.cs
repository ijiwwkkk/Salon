﻿using Microsoft.EntityFrameworkCore;
using Salon.Data;   
using Salon.Models; 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Salon.Services 
{
    public class ReportService
    {
        private readonly ApplicationDbContext _context;

        public ReportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Appointment>> GetFilteredAppointmentsAsync(string searchTerm, string status, DateTime? date)
        {
            var query = _context.Appointments
                .Include(a => a.Client)
                .Include(a => a.Master)
                .Include(a => a.Service)
                .AsQueryable();

            if (!string.IsNullOrEmpty(status) && status != "Все статусы")
                query = query.Where(a => a.Status == status);

            if (date.HasValue)
                query = query.Where(a => a.DateTime.Date == date.Value.Date);

            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(a =>
                    a.Client.FullName.Contains(searchTerm) ||
                    a.Service.Name.Contains(searchTerm) ||
                    a.Master.FullName.Contains(searchTerm));
            }

            return await query.OrderByDescending(a => a.DateTime).ToListAsync();
        }

        public async Task<Dictionary<string, int>> GetPopularServicesAsync()
        {
            return await _context.Appointments
                .Where(a => a.Status == "Выполнена")
                .GroupBy(a => a.Service.Name)
                .Select(g => new { ServiceName = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .Take(5) 
                .ToDictionaryAsync(x => x.ServiceName, x => x.Count);
        }
    }
}