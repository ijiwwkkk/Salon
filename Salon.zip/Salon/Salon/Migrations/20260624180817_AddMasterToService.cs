﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Salon.Migrations
{
    public partial class AddMasterToService : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MasterId",
                table: "Services",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Services_MasterId",
                table: "Services",
                column: "MasterId");

            migrationBuilder.AddForeignKey(
                name: "FK_Services_Users_MasterId",
                table: "Services",
                column: "MasterId",
                principalTable: "Users",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Services_Users_MasterId",
                table: "Services");

            migrationBuilder.DropIndex(
                name: "IX_Services_MasterId",
                table: "Services");

            migrationBuilder.DropColumn(
                name: "MasterId",
                table: "Services");
        }
    }
}
